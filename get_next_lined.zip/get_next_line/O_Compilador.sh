#!/bin/bash

# Caminho do arquivo C a ser monitorado
FILE_TO_MONITOR="get_next_line.c"
#!/bin/bash

cat << "EOF"
 _____ _                               
| ____| |___  ___   __ _ _ __ ___  ___ 
|  _| | / __|/ _ \ / _` | '__/ _ \/ __|
| |___| \__ \ (_) | (_| | | |  __/\__ \
|_____|_|___/\___/ \__,_|_|  \___||___/
EOF

# Verificar se o arquivo existe
if [[ ! -f "$FILE_TO_MONITOR" ]]; then
  echo "Erro: O arquivo $FILE_TO_MONITOR não foi encontrado!"
  exit 1
fi

echo "Monitorando o arquivo $FILE_TO_MONITOR para alterações..."

# Obtém o timestamp da última modificação do arquivo
LAST_MODIFICATION=$(stat -c %Y "$FILE_TO_MONITOR")

while true; do
  # Obtém a última modificação atual
  CURRENT_MODIFICATION=$(stat -c %Y "$FILE_TO_MONITOR")

  # Verifica se houve alteração no arquivo
  if [[ "$CURRENT_MODIFICATION" != "$LAST_MODIFICATION" ]]; then
    clear
      cat << "EOF"
 _____ _                               
| ____| |___  ___   __ _ _ __ ___  ___ 
|  _| | / __|/ _ \ / _` | '__/ _ \/ __|
| |___| \__ \ (_) | (_| | | |  __/\__ \
|_____|_|___/\___/ \__,_|_|  \___||___/
EOF
    echo "O arquivo $FILE_TO_MONITOR foi alterado. Compilando e executando..."

    # Compila o código C
    gcc -Wall -Wextra -Werror "$FILE_TO_MONITOR" -o output_program

    # Verifica se a compilação foi bem-sucedida
    if [[ $? -eq 0 ]]; then
      # Executa o programa compilado
      ./output_program "$FILE_TO_MONITOR"
    else
      echo "Erro: A compilação falhou."
    fi

    # Atualiza o timestamp da última modificação
    LAST_MODIFICATION=$CURRENT_MODIFICATION
  fi

  # Aguarda 1 segundo antes de verificar novamente
  sleep 1
done

