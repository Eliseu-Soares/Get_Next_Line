//#include "get_next_line.h"
#include <stdio.h>
# include "libft/ft_strjoinfree.c"
//# include "libft/ft_strdup.c"
# include "libft/ft_strchr.c"
//# include "libft/ft_strlen.c"
# include "libft/ft_bzero.c"
# include "libft/ft_strnew.c"
# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>

# define BUFF_SIZE 16
# define MAX_FD 1025

typedef struct          s_gnl
{
        struct s_gnl    *next;
        struct s_gnl    *prev;
        char                    *c;
        int                             fd;
}                                       t_gnl;

void    ft_listaddb(t_gnl *alst, t_gnl *new)
{
        if (alst != NULL && new != NULL)
        {
                alst->next = new;
                new->prev = alst;
        }
}

t_gnl   *ft_listnew(int fd)
{
        t_gnl *i;

        if (!(i = (t_gnl*)malloc(sizeof(t_gnl))))
                return (NULL);
        i->c = NULL;
        i->fd = fd;
        i->next = NULL;
        return (i);
}

int             helper(char **line, t_gnl *buffsave)
{
        char                    *e;

        e = ft_strchr(buffsave->c, '\n');
        if (e != NULL)
        {
                *e = '\0';
                *line = ft_strdup(buffsave->c);
                buffsave->c = ft_strdup(e + 1);
                return (1);
        }
        if (0 < ft_strlen((buffsave->c)))
        {
                *line = ft_strdup((buffsave->c));
                *(buffsave)->c = '\0';
                return (1);
        }
        return (0);
}

t_gnl   *listfunction(t_gnl *buffsave, int fd)
{
        while ((int)buffsave->fd < fd && buffsave)
        {
                if (!buffsave->next)
                        ft_listaddb(buffsave, ft_listnew(fd));
                buffsave = buffsave->next;
                if ((int)buffsave->fd == fd)
                        return (buffsave);
        }
        while ((int)buffsave->fd > fd && buffsave)
        {
                buffsave = buffsave->prev;
                if ((int)buffsave->fd == fd)
                        return (buffsave);
        }
        return (0);
}

int             get_next_line(const int fd, char **line)
{
        static t_gnl    *buffsave;
        char                    buf[BUFF_SIZE + 1];
        int                             check;

        if (line == NULL || fd < 0 || BUFF_SIZE <= 0 || fd >= MAX_FD)
                return (-1);
        if (buffsave && (int)buffsave->fd != fd && fd)
                buffsave = listfunction(buffsave, fd);
        if (buffsave == NULL)
                buffsave = ft_listnew(fd);
        *line = 0;
        while ((check = read(fd, buf, BUFF_SIZE)) > 0)
        {
                buf[check] = '\0';
                buffsave->c = ft_strjoinfree(buffsave->c, buf, 1);
                ft_bzero(buf, BUFF_SIZE + 1);
        }
        if (check < 0)
                return (-1);
        return (helper(line, buffsave));
}
int			 main(int argc, char **argv)
{
		int fd;
		char *line;

		if (argc < 2)
		{
				write(1, "Usage: ./gnl <file>\n", 21);
				return (1);
		}
		fd = open(argv[1], O_RDONLY);
		if (fd < 0)
		{
				perror("Error opening file");
				return (1);
		}
		while (get_next_line(fd, &line) > 0)
		{
				printf("%s\n", line);
				free(line);
		}
		close(fd);
		return (0);
}
