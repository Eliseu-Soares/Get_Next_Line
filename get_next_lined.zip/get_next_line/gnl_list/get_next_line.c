#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

#define BUFFER_SIZE 43

typedef struct __l_list
{
	char	*contain;
	int	bytes;

	struct __l_list *next;
}l_list;

typedef struct	__var
{
	int		bytes;
	char	*buffer;
	char	*tmp;
}var;
int	len(const char *str)
{
	size_t	i;

	if (!str)
		return (0);
	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}


void	bzero_(void *ptr, size_t lengh)
{
	while (lengh--)
	{
		*((unsigned char *)ptr) = 0;
		ptr++;
	}
}

void	cpylist(void *list, void *str)
{
	size_t	index;

	index = 0;
	while (index < (size_t)len(str))
	{
		((unsigned char *)list)[index] = ((unsigned char *)str)[index];
		index++;
	}
}

int	find_newline(l_list *buffer_list)
{
	size_t	i;
	i = 0;
	while (buffer_list && i < BUFFER_SIZE)
	{
		if (buffer_list->contain[i] == '\n' || buffer_list->contain[i])
			return (1);
		i++;
		buffer_list = buffer_list->next;
	}
	return (0);
}

void	free_list(l_list *buffer_list)
{
	l_list	*current_node;
	l_list	*next_node;

	if (!buffer_list)
		return ;
	current_node = buffer_list;
	while (current_node)
	{
		next_node = current_node->next;
		free(current_node->contain);
		free(current_node);
		current_node = next_node;
	}
	buffer_list = NULL;
	return ;
}

l_list	*last(l_list **buffer_list)
{
	l_list	*aux;

	if (!(aux = *buffer_list))
		return (NULL);
	while (aux->next != NULL)
		aux = aux->next;
	return (aux);
}

void	creat_node(char *buffer, l_list **buffer_list)
{
	l_list	*new_node;
	l_list	*last_node;

	if (!buffer)
		return ;
	last_node = NULL;
	last_node = last(buffer_list);
	if (!(new_node = (l_list *)malloc(sizeof(l_list))))
		return ;
	if (!(new_node->contain = (char *)malloc(BUFFER_SIZE + 1)))
	{
		free_list(new_node);
		return ;
	}
	cpylist(new_node->contain, buffer);
	if (!last_node)
	{
		*buffer_list = new_node;
		new_node->next = NULL;
	}
 	else
	{
		last_node->next = new_node;
		new_node->next = NULL;
	}
} 
//Os nós(lista) sempre serão liberados por uma função especifica
void	get_line(l_list **buffer_list, char **line)
{
	l_list	*tmp;
	size_t	i;
	
	i = 0;
	tmp = NULL;
	if (!buffer_list)
		return (free_list(*buffer_list));
	if (!(*line = (char *)malloc(BUFFER_SIZE)))
	{
		free_list(*buffer_list);
		return ;
	}
	tmp = *buffer_list;
	while (tmp)
	{
		while (tmp->contain[i] && i < BUFFER_SIZE)
		{
			if (tmp->contain[i] != '\n')
			{
				(*line)[i] = tmp->contain[i];
			}
			i++;
		}
		tmp = tmp->next;
	}
}

int	sizeline()

void	remove_line(l_list **buffer_list);
{
	l_list	*last_node;

	int	i;
	int	k;
	char	*buffer;

	buffer = (char *)malloc(BUFFER_SIZE + 1);
	if (!buffer)
		return (free_list(buffer_list));
	last_node = last()
}

void	read_line(int fd, l_list **buffer_list)
{
	var	v;
	
	v.bytes = 0;
	/* while (!(find_newline(*buffer_list)))
	{ */
	if (!(v.buffer = malloc(BUFFER_SIZE + 1)))
	return ;
	v.bytes = read(fd, v.buffer, BUFFER_SIZE);
	if (!v.bytes)
	{
		free(v.buffer);
		return ;
	}
	v.buffer[v.bytes] = '\0';
	creat_node(v.buffer, buffer_list);
	/* } */
	//printf("%s", (*buffer_list)->contain);
}

char	*get_next_line(int fd)
{
	static l_list	*buffer_list;
	char	*line;
	var c;
	
	line = NULL;
	c.bytes = 0;
	c.buffer = NULL;
	if ((c.bytes = read(fd, c.buffer, 0)) || (fd < 0) || (BUFFER_SIZE <= 0))
	return (NULL);
	//while (c.bytes != 0)
	read_line(fd, &buffer_list);
	get_line(&buffer_list, &line);

	return (line);
}

int	main(void)
{
	int	fd;
	int	i;
	char	*t;
	
	t = NULL;
	fd = open("archive.txt", O_RDONLY);
	if (!fd)
	{
		printf("Error in open file");
		return(-1);
	}
	i = 0;
	while (i < 2)
	{
		t = get_next_line(fd);
		printf("%s",t);
		//free(t);
		i++;
	}
	close(fd);
}