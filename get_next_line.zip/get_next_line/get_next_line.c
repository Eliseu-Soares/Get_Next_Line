//#include "get_next_line.h"
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#ifndef BUFFER_SIZE
#define BUFFER_SIZE 999
#endif

char	*ft_strchr(const char *str, int n)
{
	int	i;
	
	if (!str)
		return (NULL);
	i = 0;
	while(*str)
	{
		if (*str == n)
		{
			return ((char *)str);
		}
		str++;
	}
	if (n == 0)
		return ((char *)str);
	return (NULL);
}

int	len(const char *str)
{
	int	i;
	
	if (!str)
		return (0);
	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}
void	ft_bzero(const char *ptr, size_t size)
{
    size_t	i;

	i = 0;
	while (i < size)
	{
		((unsigned char *)ptr)[i] = 0;
		i++;
	}
}

 char	*ft_join(const char *s1, const char *s2)
{
	char	*ptr;
	int		i;
	int		u;

	if (!s1)
		s1 = "";
	if (!s2)
		s2 = "";
	ptr = (char *)malloc((len(s1) + len(s2)) + 1);
	i = 0;
	u = 0;
	while (s1[i])
	{
		ptr[i] = s1[i];
		i++;
	}
	while (s2[u])
	{
		ptr[i] = s2[u];
		i++;
		u++;
	}
	ptr[i] = '\0';
	return (ptr);
}

/* char	*get_line(char **stic)
{
	char	*new_line;
	size_t	i;
	size_t	u;
	
	i = 0;
	while (*stic[i] != '\n')
		i++;
	new_line = (char *)malloc(i + 1);
	u = 0;
	while (u < i)
	{
		new_line[u] = *stic[u];
		u++;
	}
		return (new_line);
} */
	
void	read_line(int fd, char **stic)
	{
		int	bytes;
		char	*buffer;
		char	*aux;
		
/* 		if (fd == 0 || BUFFER_SIZE)
		{
			return	;
		} */
		ft_bzero(buffer, BUFFER_SIZE + 1);
		bytes = read(fd, buffer, (BUFFER_SIZE));
		aux = (char *)malloc(BUFFER_SIZE + 1);
		
		aux = ft_join(*stic, buffer);
		
		free(*stic);
		*stic = NULL;
		
		*stic = aux;
	}
	
	char	*get_next_line(int fd)
	{
		static char	*stic;
		char	*resul;
		char	*n;
		
		while (ft_strchr(stic, '\n') == NULL)
			read_line(fd, &stic);
		
	//free (buffer);
	//n = get_line(&stic);
	printf("%d",)
	return (stic);
 
}

int main(void)
{
    int fd;
	int	i;
	char	*n;
    //char    buffer[150];

	i = 0;
	fd = 0;
    fd = open("archive.txt", O_RDONLY);
    if (fd < 0)
        printf("Error open file!");
		while (i < 1)
		{ 
			n = get_next_line(fd);
			printf("%s", n);
			i++;
		}
}
