//#include "get_next_line.h"
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#ifndef BUFFER_SIZE
#define BUFFER_SIZE 100
#endif

char	*ft_strchr(const char *str, int n)
{
	int	i;

	if (!str)
		return (NULL);
	i = 0;
	while(*str)
	{
		if (*str == n)
		{
			return ((char *)str);
		}
		str++;
	}
	if (n == 0)
		return ((char *)str);
	return (NULL);
}

int	len(const char *str)
{
	int	i;

	if (!str)
		return (0);
	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}
void	ft_bzero(const char *ptr, size_t size)
{
    size_t	i;

	i = 0;
	while (i < size)
	{
		((unsigned char *)ptr)[i] = 0;
		i++;
	}
}

 char	*ft_join(const char *s1, const char *s2)
{
	char	*ptr;
	int		i;
	int		u;

	if (!s1)
		s1 = "";
	if (!s2)
		s2 = "";
	ptr = (char *)malloc((len(s1) + len(s2)) + 1);
	i = 0;
	u = 0;
	while (s1[i])
	{
		ptr[i] = s1[i];
		i++;
	}
	while (s2[u])
	{
		ptr[i] = s2[u];
		i++;
		u++;
	}
	ptr[i] = '\0';
	return (ptr);
}

void	get_line(char **stic, char **new_line,char *buffer)
{
	size_t	i;
	size_t	u;
 
 	i = 0;
	
/* 	if (!ft_strchr(*stic, '\n'))
	{
		free(*stic);
		*stic = NULL;
		return ;
	} */
 	while ((*stic)[i] != '\n')
		i++;
	*new_line = (char *)malloc(i + 1);
	ft_bzero(*new_line, i + 1);
	u = 0;
	i += 1;
	while (i--)
	{
		(*new_line)[u] = (*stic)[u];
		u++;
	}
	(*new_line)[u] = '\0';
}

char	*remove_line(char **stic)
{
	size_t	i;
	size_t	nl;
	int	x;
	int	j;
	char	*rm_line;

  
	x = 0;
	i = 0;
	j = 0;
/* 	if (!ft_strchr(*stic, '\n'))
	{
		free(*stic);
		stic = NULL;
		return NULL;
	} */
	nl = len(*stic);
	while ((*stic)[i] != '\n')
		i++;
		i += 1;
	rm_line = (char *)malloc(nl - i);
//	printf("Here: %ld\n",nl - i);
	ft_bzero(rm_line, nl - i);
	j = (nl - i);
	while (x < j)
	{
		rm_line[x] = (*stic)[i];
		x++;
		i++;
	}
	rm_line[x] = '\0';
	free(*stic);
	*stic = NULL;
	*stic = rm_line;
	return (*stic);
}

int	read_line(int fd, char **stic)
{
	int		bytes;
	char	*buffer;
	char	*aux;

	buffer = (char *)malloc(BUFFER_SIZE + 1);
	ft_bzero(buffer, BUFFER_SIZE + 1);
	bytes = (int)read(fd, buffer, (BUFFER_SIZE));
	if (fd == -1)
		return (-1);
	aux = (char *)malloc(BUFFER_SIZE + 1);

	aux = ft_join(*stic, buffer);

	free(*stic);
	*stic = NULL;
	*stic = aux;
	return (bytes);
}

char	*get_next_line(int fd)
{
	static char	*stic;
	char	*result;
	char	*buffer;
	int		bytes;
	char	*j;

	/* if (bytes < 0 || BUFFER_SIZE <= 0)
		return NULL; */
		bytes = 1;
	while ((ft_strchr(stic, '\n') == NULL) && (bytes != 0))
		bytes = read_line(fd, &stic);
	if (bytes < 0 && BUFFER_SIZE <= 0)
		return (NULL);
	get_line(&stic, &result, buffer);
	j = remove_line(&stic);
/* 	if (len(stic) == 0)
	return (NULL); */
	return (result);

}
 
int main(void)
{
    int fd;
	int	i;
	char	*n;
    //char    buffer[150];

	i = 0;
	fd = 0;
    fd = open("archive.txt", O_RDONLY);
    if (fd < 0)
        printf("Error open file!");
		while (i < 90)
		{
			n = get_next_line(fd);
			printf("%s", n);
			i++;
			free(n);
		}
		close(fd);
}
