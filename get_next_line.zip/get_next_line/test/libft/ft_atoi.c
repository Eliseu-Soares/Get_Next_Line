/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/15 16:35:40 by elsoares          #+#    #+#             */
/*   Updated: 2025/07/05 17:47:59 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

static int	check_over(long resul, int ptr, int signal)
{
	if ((signal == 1) && resul > ((long long)LONG_MAX - ptr) / 10)
	{
		return (-1);
	}
	else if ((signal == -1) && - resul < ((long long)LONG_MIN + ptr) / 10)
		return (0);
	return (4);
}

int	ft_atoi(const char *nptr)
{
	int		signal;
	int		n;
	long	result;

	if (!nptr)
		return (0);
	result = 0;
	signal = 1;
	while (*nptr == ' ' || (*nptr >= 9 && *nptr <= 13))
		nptr++;
	if (*nptr == '-' || *nptr == '+')
	{
		if (*nptr == '-')
			signal = -1;
		nptr++;
	}
	while (*nptr >= '0' && *nptr <= '9' )
	{
		n = check_over(result, (*nptr - '0' ), signal);
		if (n != 4)
			return (n);
		result = result * 10 + *nptr - '0';
		nptr++;
	}
	return ((int)(result * signal));
}
