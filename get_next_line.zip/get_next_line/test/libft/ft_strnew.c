#include "libft.h"

char	*ft_strnew(size_t size)
{
	char	*newmem;
	size_t	i;

	i = 0;
	newmem = (char*)malloc(sizeof(char) * size + 1);
	if (newmem == NULL)
		return (NULL);
	ft_bzero(newmem, size + 1);
	return (newmem);
}
