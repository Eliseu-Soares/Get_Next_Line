/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/20 11:06:11 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/20 13:14:46 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "libft.h"

static char	*concatenate(char const *prefix, char const *suffix, size_t len)
{
	char	*ptr;
	size_t	index1;
	size_t	index2;

	ptr = (char *)malloc(sizeof (char) * (len + 1));
	if (!ptr)
		return (NULL);
	index1 = 0;
	index2 = 0;
	while (prefix[index1])
	{
		ptr[index1] = prefix[index1];
		index1++;
	}
	while (suffix[index2])
	{
		ptr[index1] = suffix[index2];
		index2++;
		index1++;
	}
	ptr[index1] = '\0';
	return (ptr);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	size_t	len_total;

	if (!s1 || !s2)
		return (NULL);
	len_total = (ft_strlen(s1) + ft_strlen(s2));
	return (concatenate(s1, s2, len_total));
}
