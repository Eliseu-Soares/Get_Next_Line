/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elsoares <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/16 12:05:35 by elsoares          #+#    #+#             */
/*   Updated: 2025/06/16 18:59:19 by elsoares         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strdup(const char *s)
{
	size_t	i;
	size_t	len_s;
	char	*new_vector;

	if (!s)
		return (NULL);
	len_s = 0;
	i = 0;
	while (s[len_s])
		len_s++;
	new_vector = (char *)malloc(sizeof(char) * (len_s + 1));
	if (!new_vector)
		return (NULL);
	while (i < len_s)
	{
		new_vector[i] = s[i];
		i++;
	}
	new_vector[len_s] = '\0';
	return (new_vector);
}
