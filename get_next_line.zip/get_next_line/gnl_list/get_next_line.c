#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

#define BUFFER_SIZE 42

typedef struct __l_list
{
	char	*contain;
	int	bytes;

	struct __l_list *next;
}l_list;

typedef struct	__var
{
	int		bytes;
	char	*tmp;
}var;

int	len(const char *str)
{
	size_t	i;

	if (!str)
		return (0);
	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

char	*join_(const char *str1, const char *str2)
{
	size_t	u;
	size_t	b;
	char	*ptr;

	unsigned char	*s1;
	unsigned char	*s2;

	s1 = (unsigned char *)str1;
	s2 = (unsigned char *)str2;
	ptr = NULL;
	ptr = (char *)malloc((len(s1) + len(s2)) + 1);
	u = 0;
	b = 0;
	while (s1 && s1[u])
	{
		ptr[u] = s1[u];
		u++;
	}
	while (s2 && s2[b])
		ptr[u++] = s2[b++];
	ptr[u - 1] = '\0';
	return (ptr);
}

void	bzero_(void *ptr, size_t lengh)
{
	while (lengh--)
	{
		*((unsigned char *)ptr) = 0;
		ptr++;
	}
}

int	read_line(int fd, char **stic)
{
	l_list	*new;
	var	v;

	if (fd < 0)
		return (-1);
	new = (l_list *)malloc(sizeof(l_list));
	if (!new)
	return (-1);
	new->contain = (char *)malloc(BUFFER_SIZE * sizeof(char));
	if (!new->contain)
	{
		free(new);
		return (-1);
	}
	v.bytes = 0;
	v.bytes = read(fd, new->contain, BUFFER_SIZE);
	if (v.bytes <= 0)
		return (v.bytes);
	new->contain[v.bytes] = '\0';
	v.tmp = NULL;
	v.tmp = join_(*stic, new->contain);
	//A cada leitura o stic será reiniciado
	//Depois disso será concatenado com o novo buffer
	free(*stic);
	*stic = NULL;
	*stic = v.tmp;
	return (v.bytes);
}

void	get_line(char **stic)
{
	
}

char	*get_next_line(int fd)
{
	static char	*stic;
	var	c;

	c.bytes = 1;
	while (c.bytes != 0)
		c.bytes = read_line(fd, &stic);
	
	get_line(*stic);
	return (stic);
	
}

int	main(void)
{
	int	fd;
	int	i;
	char	*t;

	fd = open("archive.txt", O_RDONLY);
	if (!fd)
	{
		printf("Error in open file");
		return(-1);
	}
	i = 0;
	while ((t = get_next_line(fd)) != NULL)
	{
		printf("%s",t);
		//free(t);
		i++;
	}
	close(fd);
}