#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>

#define BUFFER_SIZE 42

typedef struct __l_list
{
	char	*contain;
	int	bytes;

	struct __l_list *next;
}l_list;

typedef struct	__var
{
	int		bytes;
	char	*buffer;
	char	*tmp;
}var;

int	len(const char *str)
{
	size_t	i;

	if (!str)
		return (0);
	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

char	*join_(const char *str1, const char *str2)
{
	size_t	u;
	size_t	b;
	char	*ptr;

	unsigned char	*s1;
	unsigned char	*s2;

	s1 = (unsigned char *)str1;
	s2 = (unsigned char *)str2;
	ptr = NULL;
	ptr = (char *)malloc((len(str1) + len(str2)) + 1);
	u = 0;
	b = 0;
	while (s1 && s1[u])
	{
		ptr[u] = s1[u];
		u++;
	}
	while (s2 && s2[b])
		ptr[u++] = s2[b++];
	ptr[u - 1] = '\0';
	return (ptr);
}

void	bzero_(void *ptr, size_t lengh)
{
	while (lengh--)
	{
		*((unsigned char *)ptr) = 0;
		ptr++;
	}
}

void	cpylist(void *list, void *str)
{
	size_t	index;

	index = 0;
	while (index < (size_t)len(str))
	{
		((unsigned char *)list)[index] = ((unsigned char *)str)[index];
		index++;
	}
}

/* void	add_to_list(char buffer, **buffer_list)
{

} */

/* void	find_newline(char **buffer_list)
{
	size_t	i;
	i = 0;
	while (buffer_list[i] && i < BUFFER_SIZE)
	{
		if (buffer_list[i] == '\n' || buffer_list[i])
			return (1);
		i++;
	}
	return (0);
} */

char	*creat_node(char *buffer)
{
	l_list	*buff_node;

	if (!(buff_node = (l_list *)malloc(sizeof(l_list))))
		return (NULL);
	if (!(buff_node->contain = (char *)malloc(BUFFER_SIZE + 1)))
		return (NULL);
	buff_node->next = NULL;
	cpylist(buff_node->contain, buffer);
	return (buff_node->contain);
}

/* void	get_line()
{

} */

/* void	clean_list()
{

} */

/* void	free_list()
{

} */

int	read_line(int fd, char **buffer_list)
{
	var	v;

	v.bytes = 0;
	v.buffer = malloc(BUFFER_SIZE + 1);
	v.bytes = read(fd, v.buffer, BUFFER_SIZE);

	
	*buffer_list = malloc(BUFFER_SIZE + 1); 
	cpylist(*buffer_list, creat_node(v.buffer));
	v.buffer[v.bytes] = '\0';
	//printf("Aqui: %s\n", v.buffer);
	return (v.bytes);
}

char	*get_next_line(int fd)
{
	static char *buffer_list;
	//var c;

	//c.bytes = 0;
	//c.buffer = NULL;
/* 	if ((c.bytes = read(42, c.buffer, 0)) || fd < 0 || BUFFER_SIZE <= 0)
		return (NULL); */

	//while (c.bytes != 0)
	read_line(fd, &buffer_list);
	
//	get_line(*buffer_list);
	return (buffer_list);
}

int	main(void)
{
	int	fd;
	int	i;
	char	*t;

	fd = open("archive.txt", O_RDONLY);
	if (!fd)
	{
		printf("Error in open file");
		return(-1);
	}
	i = 0;
	while (i < 2)
	{
		t = get_next_line(fd);
		printf("%s",t);
		//free(t);
		i++;
	}
	close(fd);
}